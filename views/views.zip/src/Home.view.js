/* eslint-disable jsx-a11y/accessible-emoji */
import React from 'react';
import { withRouter } from 'react-router';
import makeTests from './Home.view.tests.js';
import { Link } from 'react-router-dom';
import './Home.view.css';
const styles = { h1lmw638: 'css-1s0kfvh' };

const g = typeof window === 'undefined' ? global : window;

class TestsHome extends React.Component {
  constructor(props) {
    super(props);

    const { _main, ...rest } = makeTests(this.display);
    this.state = {
      ...rest[_main],
      _on: true,
    };

    const tests = {
      active: _main,
      on: this.on,
      off: this.off,
    };

    Object.keys(rest).forEach(test => {
      tests[test] = () => this.display(rest[test], test);
    });

    if (typeof g.tests === 'undefined') {
      const validTests = k => !(k === 'off' || k === 'on');
      g.tests = {
        off: () =>
          Object.keys(g.tests)
            .filter(validTests)
            .forEach(t => g.tests[t].off()),
        on: () =>
          Object.keys(g.tests).filter(validTests).forEach(t => g.tests[t].on()),
      };
    }

    if (typeof g.tests.Home === 'undefined') {
      g.tests.Home = tests;
    } else if (Array.isArray(g.tests.Home)) {
      g.tests.Home.push(tests);
    } else {
      g.tests.Home = [g.tests.Home, tests];
      g.tests.Home.off = () => g.tests.Home.forEach(t => t.off());
      g.tests.Home.on = () => g.tests.Home.forEach(t => t.on());
    }

    this.test = tests;

    console.info('Home tests 👉', g.tests);
  }

  componentWillUnmount() {
    if (Array.isArray(g.tests.Home)) {
      g.tests.Home = g.tests.Home.filter(t => t === this.tests);
      if (g.tests.Home.length === 0) {
        delete g.tests.Home;
      }
    } else {
      delete g.tests.Home;
    }
  }

  display = (next, name) => {
    this.setState({ ...next, _on: true }, () => {
      g.tests.Home.active = name;
    });
  };

  off = () => this.setState({ _on: false });
  on = () => this.setState({ _on: true });

  render() {
    const { _on, ...state } = this.state;
    return _on ? <Home {...this.props} {...state} /> : <Home {...this.props} />;
  }
}

const Home = props =>
  <div text={item.name} className={styles.h1lmw638}>
    {Array.isArray(props.brands) &&
      props.brands.map((item, i) =>
        <Link
          to={`${props.match.url === '/' ? '' : props.match.url}/bluemix`}
          text={item.name}
          className={styles.h1lmw638}
          key={i}
        >
          <div>{item.name}</div>
        </Link>
      )}
    {props.children}
  </div>;

export default withRouter(TestsHome);
// fonts {}
