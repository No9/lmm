/* eslint-disable jsx-a11y/accessible-emoji */
import React from 'react';
import Home from './Home.view.js';
import { Route } from 'react-router-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import './App.view.css';
const styles = { hdhehq9: 'css-th0lnu' };

const App = props =>
  <Router>
    <div className={styles.hdhehq9}>
      <div>javascript</div>
      <Route path="/" exact render={routeProps => <Home {...routeProps} />} />
      {props.children}
    </div>
  </Router>;

export default App;
// fonts {}
