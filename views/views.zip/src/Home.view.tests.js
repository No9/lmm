export default display => {
  const Main = { brands: [{ name: 'SaaS' }, { name: 'Bluemix' }] };
  return { _main: 'Main', Main };
};
