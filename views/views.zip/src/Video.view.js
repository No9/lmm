/* eslint-disable jsx-a11y/accessible-emoji */
import React from 'react';

const Video = props => <div>video</div>;

export default Video;
// fonts {}
